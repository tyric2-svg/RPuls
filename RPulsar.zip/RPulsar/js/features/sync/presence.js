// js/features/sync/presence.js  (v2 — исправлен crash)
// =====================================================================
// RPulsar Presence System
// Показывает, кто онлайн и кто какую задачу редактирует.
// Использует ОТДЕЛЬНУЮ упрощённую запись (без backup/rotation) —
// presence файлы не критичны, их потеря не проблема.
// =====================================================================
window.App = window.App || {};

App.presence = {
    heartbeatInterval: 10000,
    offlineTimeout: 30000,
    polling: null,
    onlineUsers: new Map(),
    maxVisibleAvatars: 5,
    // 🔧 ЗАЩИТА ОТ КРАША: не пишем чаще чем раз в 5 секунд,
    // даже если событие (editTask/openTaskDetail) вызывается много раз
    _lastWriteAt: 0,
    _writeThrottleMs: 5000,
    _pendingWrite: false
};

// =====================================================================
// УПРОЩЁННАЯ ЗАПИСЬ (без backup, rotation, верификации)
// =====================================================================
// Presence файлы не критичны: если один повреждён — через 30 сек он
// считается offline и пересоздаётся. Поэтому используем прямую запись
// одним вызовом createWritable().write().close() без всех тяжёлых
// механизмов syncAtomicWrite. Это уменьшает нагрузку на SMB в 10 раз.
// =====================================================================

/**
 * Прямая быстрая запись presence без backup/rotation.
 * Безопасно для частых вызовов (heartbeat + события редактирования).
 */
App.presenceWriteSimple = async function() {
    if (!App.sync.handle || !App.state.currentUser) return;

    const user = App.state.users.find(u => u.id === App.state.currentUser);
    if (!user) return;

    const fileName = '_presence-' + App.state.currentUser + '.json';
    const data = {
        userId: App.state.currentUser,
        name: user.name,
        color: user.color || '#6B7280',
        lastSeen: new Date().toISOString(),
        editing: App.ui.currentTask || null,
        view: App.state.view || 'table',
        section: App.state.currentSection || 'tasks',
        appVersion: '4.72'
    };

    try {
        const fileHandle = await App.sync.handle.getFileHandle(fileName, { create: true });
        const writable = await fileHandle.createWritable();
        await writable.write(JSON.stringify(data, null, 2));
        await writable.close();
    } catch (e) {
        // Тихо логируем — presence не критичен, следующий heartbeat перепишет
        console.debug('[Presence] Ошибка записи (некритично):', e);
    }
};

/**
 * Записывает presence с throttle: не чаще раза в 5 секунд.
 * Если вызов приходит раньше — запоминаем флаг и ждём следующего heartbeat.
 */
App.presenceWrite = async function() {
    const now = Date.now();
    const elapsed = now - App.presence._lastWriteAt;

    if (elapsed < App.presence._writeThrottleMs) {
        // Ещё рано — ставим флаг, heartbeat подхватит
        App.presence._pendingWrite = true;
        return;
    }

    App.presence._lastWriteAt = now;
    App.presence._pendingWrite = false;
    await App.presenceWriteSimple();
};

// =====================================================================
// ЧТЕНИЕ PRESENCE
// =====================================================================

/**
 * Читает только presence файлы (фильтр по имени) — не сканирует всю папку.
 */
App.presenceRead = async function() {
    if (!App.sync.handle) return;

    const onlineUsers = new Map();
    const now = Date.now();
    const offlineTimeout = App.presence.offlineTimeout;

    try {
        for await (const entry of App.sync.handle.values()) {
            // ФИЛЬТР: только presence файлы
            if (entry.kind !== 'file') continue;
            if (!entry.name.startsWith('_presence-')) continue;
            if (!entry.name.endsWith('.json')) continue;

            try {
                const file = await entry.getFile();
                const text = await file.text();
                if (!text.trim()) continue;

                const data = JSON.parse(text);
                const lastSeen = new Date(data.lastSeen).getTime();

                if (now - lastSeen < offlineTimeout) {
                    onlineUsers.set(data.userId, data);
                }
                // Устаревшие файлы не удаляем — могут не быть прав
            } catch (e) {
                // Повреждённый presence файл — пропускаем
            }
        }

        App.presence.onlineUsers = onlineUsers;
        App.presenceRender();
    } catch (e) {
        console.debug('[Presence] Ошибка чтения (некритично):', e);
    }
};

// =====================================================================
// РЕНДЕРИНГ UI (без изменений)
// =====================================================================

App.presenceRender = function() {
    const onlineUsers = Array.from(App.presence.onlineUsers.values())
        .filter(u => u.userId !== App.state.currentUser);

    App.presenceRenderHeaderAvatars(onlineUsers);
    App.presenceRenderEditingIndicators();
    App.presenceRenderDrawerWarning();
};

App.presenceRenderHeaderAvatars = function(onlineUsers) {
    let container = document.getElementById('presenceAvatars');

    if (!container) {
        const headerActions = document.querySelector('.header-actions');
        if (!headerActions) return;

        container = document.createElement('div');
        container.id = 'presenceAvatars';
        container.className = 'presence-avatars';
        headerActions.insertBefore(container, headerActions.firstChild);
    }

    const maxVisible = App.presence.maxVisibleAvatars;
    const visible = onlineUsers.slice(0, maxVisible);
    const extra = onlineUsers.length - maxVisible;

    let html = '';
    visible.forEach(user => {
        const initials = user.name.split(' ')
            .map(n => n[0])
            .join('')
            .substring(0, 2)
            .toUpperCase();
        html += `
            <div class="presence-avatar"
                 style="background: ${App.safeColor(user.color)}"
                 title="${App.escapeHtml(user.name)} — онлайн"
                 data-user-id="${user.userId}">
                ${initials}
            </div>
        `;
    });

    if (extra > 0) {
        html += `
            <div class="presence-avatar presence-avatar-more"
                 title="Ещё ${extra} онлайн">
                +${extra}
            </div>
        `;
    }

    container.innerHTML = html;
};

App.presenceRenderEditingIndicators = function() {
    const editingMap = new Map();
    App.presence.onlineUsers.forEach(user => {
        if (user.editing && user.userId !== App.state.currentUser) {
            editingMap.set(user.editing, user);
        }
    });

    // Таблица
    const rows = document.querySelectorAll('.task-row');
    rows.forEach(row => {
        const taskId = row.dataset.taskId;
        const editor = editingMap.get(taskId);

        let indicator = row.querySelector('.presence-editing-indicator');
        if (editor) {
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'presence-editing-indicator';
                const lastCell = row.querySelector('td:last-child');
                if (lastCell) lastCell.appendChild(indicator);
                else row.appendChild(indicator);
            }
            indicator.innerHTML = `
                <span class="presence-editing-dot"
                      style="background: ${App.safeColor(editor.color)}"></span>
                <span class="presence-editing-name">
                    ${App.escapeHtml(editor.name)} редактирует
                </span>
            `;
        } else if (indicator) {
            indicator.remove();
        }
    });

    // Канбан
    const cards = document.querySelectorAll('.kanban-card');
    cards.forEach(card => {
        const taskId = card.dataset.taskId;
        const editor = editingMap.get(taskId);

        let indicator = card.querySelector('.presence-editing-indicator');
        if (editor) {
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'presence-editing-indicator presence-editing-indicator-kanban';
                card.appendChild(indicator);
            }
            indicator.innerHTML = `
                <span class="presence-editing-dot"
                      style="background: ${App.safeColor(editor.color)}"></span>
            `;
        } else if (indicator) {
            indicator.remove();
        }
    });
};

App.presenceRenderDrawerWarning = function() {
    if (!App.ui.currentTask || !App.ui.drawerOpen) return;

    const editor = Array.from(App.presence.onlineUsers.values())
        .find(u => u.editing === App.ui.currentTask && u.userId !== App.state.currentUser);

    let warning = document.getElementById('presenceDrawerWarning');

    if (editor) {
        if (!warning) {
            warning = document.createElement('div');
            warning.id = 'presenceDrawerWarning';
            warning.className = 'presence-drawer-warning';
            const drawerBody = document.getElementById('drawerBody');
            if (drawerBody) drawerBody.insertBefore(warning, drawerBody.firstChild);
        }
        warning.innerHTML = `
            <span class="icon icon-sm" data-icon="alert-circle"></span>
            <span>${App.escapeHtml(editor.name)} сейчас редактирует эту задачу.
                  Ваши изменения могут конфликтовать.</span>
        `;
        if (App.renderAllIcons) App.renderAllIcons();
    } else if (warning) {
        warning.remove();
    }
};

// =====================================================================
// УПРАВЛЕНИЕ HEARTBEAT
// =====================================================================

App.presenceStart = function() {
    App.presenceStop();

    App.presenceWrite();
    App.presenceRead();

    App.presence.polling = setInterval(() => {
        App.presenceWrite();
        App.presenceRead();
        // Если были отложенные события (editing) — дописываем
        if (App.presence._pendingWrite) {
            App.presence._lastWriteAt = 0; // сбрасываем throttle
            App.presenceWrite();
        }
    }, App.presence.heartbeatInterval);
};

App.presenceStop = function() {
    if (App.presence.polling) {
        clearInterval(App.presence.polling);
        App.presence.polling = null;
    }
};

// =====================================================================
// УПРАВЛЕНИЕ РЕДАКТИРОВАНИЕМ (non-blocking, через throttle)
// =====================================================================

/**
 * Устанавливает редактируемую задачу.
 * НЕ блокирует UI — запись асинхронная с throttle.
 */
App.presenceSetEditing = function(taskId) {
    App.ui.currentTask = taskId;
    // Вызываем через Promise.resolve, чтобы не блокировать editTask
    Promise.resolve().then(() => App.presenceWrite());
};

/**
 * Очищает редактирование.
 */
App.presenceClearEditing = function() {
    App.ui.currentTask = null;
    Promise.resolve().then(() => App.presenceWrite());
};