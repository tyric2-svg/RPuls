// js/features/sync/sync.js
window.App = window.App || {};

App.sync = {
    handle: null,
    polling: null,
    syncing: false,
    intervalMs: 5000,
    sharedKeys: ['tasks', 'statuses', 'users', 'columns', 'templates', 'relations', 'taskOrder', '_tombstones', 'changeLog'],
    baseVersions: new Map(),
};

App.syncSupported = function() {
    return typeof window.showDirectoryPicker === 'function';
};

App.syncDbOpen = function() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open('rpulsar_sync', 1);
        req.onupgradeneeded = () => req.result.createObjectStore('handles');
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
};

App.syncSaveHandle = async function(handle) {
    const db = await App.syncDbOpen();
    await new Promise((resolve, reject) => {
        const tx = db.transaction('handles', 'readwrite');
        tx.objectStore('handles').put(handle, 'shared_file');
        tx.oncomplete = resolve;
        tx.onerror = () => reject(tx.error);
    });
};

App.syncLoadHandle = async function() {
    try {
        const db = await App.syncDbOpen();
        return await new Promise((resolve, reject) => {
            const tx = db.transaction('handles', 'readonly');
            const req = tx.objectStore('handles').get('shared_file');
            req.onsuccess = () => resolve(req.result || null);
            req.onerror = () => reject(req.error);
        });
    } catch (e) {
        console.error('syncLoadHandle failed:', e);
        return null;
    }
};

App.syncClearHandle = async function() {
    try {
        const db = await App.syncDbOpen();
        const tx = db.transaction('handles', 'readwrite');
        tx.objectStore('handles').delete('shared_file');
    } catch (e) {
        console.error('syncClearHandle failed:', e);
    }
};

App.syncVerifyPermission = async function(handle, requestIfNeeded) {
    const opts = {mode: 'readwrite'};
    if ((await handle.queryPermission(opts)) === 'granted') return true;
    if (!requestIfNeeded) return false;
    return (await handle.requestPermission(opts)) === 'granted';
};

App.syncSetStatus = function(status) {
    App.sync.status = status;
    const dot = App.elements.syncStatusDot;
    if (dot) {
        dot.classList.remove('connected', 'syncing', 'error');
        const labels = {
            disconnected: 'Не подключено',
            connected: 'Синхронизировано',
            syncing: 'Синхронизация...',
            error: 'Ошибка синхронизации',
            'needs-permission': 'Нужно повторное разрешение',
        };
        if (status === 'connected') dot.classList.add('connected');
        else if (status === 'syncing') dot.classList.add('syncing');
        else if (status === 'error' || status === 'needs-permission') dot.classList.add('error');
        dot.title = labels[status] || status;
    }
    if (App.elements.drawerBody?.querySelector('.sync-panel-row')) {
        App.renderSyncPanel();
    }
};

App.openSyncPanel = function() {
    App.renderSyncPanel();
};

App.renderSyncPanel = function() {
    const status = App.sync.status || 'disconnected';
    const labels = {
        disconnected: 'Не подключено',
        connected: 'Синхронизировано',
        syncing: 'Синхронизация...',
        error: 'Ошибка синхронизации',
        'needs-permission': 'Нужно повторное разрешение',
    };
    const html = `
        <div class="sync-panel-row">
            <span class="sync-panel-label">Статус</span>
            <span class="sync-panel-value">${labels[status] || status}</span>
        </div>
        ${App.sync.lastSyncedAt ? `
        <div class="sync-panel-row">
            <span class="sync-panel-label">Последняя синхронизация</span>
            <span class="sync-panel-value">${App.formatRelativeTime(App.sync.lastSyncedAt)}</span>
        </div>` : ''}
        <p class="text-muted" style="margin: 16px 0; font-size: 13px;">
            Задачи, статусы, пользователи, столбцы, шаблоны и связи хранятся в общем файле
            в сетевой папке и синхронизируются каждые ${Math.round(App.sync.intervalMs / 1000)} секунд.
            Личные настройки (тема, фильтры, текущий пользователь) синхронизации не подлежат.
            Резервные копии создаются автоматически при каждом сохранении.
        </p>`;
    const footer = status === 'disconnected'
        ? `<button class="btn btn-primary" id="syncConnectBtn">Подключить</button>`
        : status === 'needs-permission'
            ? `<button class="btn btn-primary" id="syncReconnectBtn">Восстановить доступ</button>
               <button class="btn btn-secondary" id="syncDisconnectBtn">Отключить</button>`
            : `<button class="btn btn-secondary" id="syncDisconnectBtn">Отключить</button>`;
    App.openDrawer('Общая папка', html, footer);
    document.getElementById('syncConnectBtn')?.addEventListener('click', () => App.syncConnect());
    document.getElementById('syncReconnectBtn')?.addEventListener('click', () => App.syncReconnect());
    document.getElementById('syncDisconnectBtn')?.addEventListener('click', () => {
        App.syncDisconnect();
        App.closeDrawer();
    });
};

// --- Слияние данных ---

App.syncGetBase = function() {
    try {
        const raw = localStorage.getItem('rtasks_sync_base');
        return raw ? JSON.parse(raw) : {};
    } catch (e) {
        return {};
    }
};

App.syncSetBase = function(base) {
    try {
        localStorage.setItem('rtasks_sync_base', JSON.stringify(base));
    } catch (e) {
        console.error('syncSetBase failed:', e);
    }
};

App.syncMergeTasks = function(localTasks, remoteTasks, localTomb, remoteTomb) {
    const tombMap = new Map();
    [...localTomb, ...remoteTomb].forEach(t => {
        const existing = tombMap.get(t.id);
        if (!existing || t.deletedAt > existing.deletedAt) tombMap.set(t.id, t);
    });

    const byId = new Map();
    localTasks.forEach(t => byId.set(t.id, {local: t}));
    remoteTasks.forEach(t => {
        const entry = byId.get(t.id) || {};
        entry.remote = t;
        byId.set(t.id, entry);
    });

    const result = [];
    byId.forEach(({local, remote}, id) => {
        const tomb = tombMap.get(id);
        let winner = local;
        if (remote) {
            const lVersion = local?.version || 1;
            const rVersion = remote?.version || 1;
            if (rVersion > lVersion) {
                winner = remote;
            } else if (lVersion > rVersion) {
                winner = local;
            } else {
                const lTime = local?.updatedAt || local?.createdAt || '';
                const rTime = remote?.updatedAt || remote?.createdAt || '';
                winner = (!local || rTime > lTime) ? remote : local;
            }
        }
        if (tomb) {
            const winnerTime = winner?.updatedAt || winner?.createdAt || '';
            if (tomb.deletedAt >= winnerTime) return;
        }
        if (winner) result.push(winner);
    });

    return {tasks: result, tombstones: [...tombMap.values()]};
};

App.syncMergeConfigArray = function(key, localArr, remoteArr, baseArr) {
    if (!baseArr && Array.isArray(remoteArr) && remoteArr.length > 0) {
        return remoteArr;
    }

    const baseStr = JSON.stringify(baseArr || null);
    const localStr = JSON.stringify(localArr);
    const remoteStr = JSON.stringify(remoteArr);
    const localChanged = localStr !== baseStr;
    const remoteChanged = remoteStr !== baseStr && remoteArr !== undefined;

    if (localChanged && remoteChanged && localStr !== remoteStr) {
        App.showToast(`Конфликт в разделе "${key}" — оставлены ваши локальные изменения`, 'info');
        return localArr;
    }
    if (!localChanged && remoteChanged) return remoteArr;
    return localArr;
};

App.syncPullMerge = async function(rawText) {
    let remote;
    try {
        remote = JSON.parse(rawText);
    } catch (e) {
        console.error('Общий файл повреждён, JSON не парсится:', e);
        return;
    }

    if (!App.isObjectSafe(remote) || !App.validateImportedData(remote).valid) {
        console.error('Общий файл не прошёл валидацию, слияние пропущено');
        return;
    }

    App._syncFingerprintBefore = App.getStateFingerprint();

    const base = App.syncGetBase();
    const {tasks, tombstones} = App.syncMergeTasks(
        App.state.tasks, remote.tasks || [],
        App.state._tombstones || [], remote._tombstones || []
    );
    App.state.tasks = tasks;
    App.state._tombstones = tombstones;

    App.state.changeLog = App.mergeChangeLog(App.state.changeLog || [], remote.changeLog || []);

    if (!App.sync.baseVersions) App.sync.baseVersions = new Map();
    (remote.tasks || []).forEach(t => {
        if (t && t.id) {
            App.sync.baseVersions.set(t.id, t.version || 1);
        }
    });
    const remoteIds = new Set((remote.tasks || []).map(t => t.id));
    for (const [id] of App.sync.baseVersions) {
        if (!remoteIds.has(id)) {
            App.sync.baseVersions.delete(id);
        }
    }

    ['statuses', 'users', 'columns', 'templates', 'relations', 'taskOrder'].forEach(key => {
        App.state[key] = App.syncMergeConfigArray(key, App.state[key], remote[key], base[key]);
    });

    App.syncTaskOrder();

    const fingerprintAfter = App.getStateFingerprint();
    const dataChanged = App._syncFingerprintBefore !== fingerprintAfter;

    App._suppressSkeletons = true;
    App.saveState();

    if (dataChanged) {
        App.render();
    } else {
        console.debug('[Sync] Данные не изменились, render пропущен');
    }
    App._suppressSkeletons = false;

    App.updateCurrentUserDisplay?.();

    if (App.ui.currentTask && App.ui.drawerOpen) {
        const currentTaskId = App.ui.currentTask;
        const remoteChangedTask = (remote.tasks || []).find(t => t.id === currentTaskId);
        const localTask = App.state.tasks.find(t => t.id === currentTaskId);
        if (remoteChangedTask && localTask) {
            const remoteUpdated = new Date(remoteChangedTask.updatedAt || 0).getTime();
            const localUpdated = new Date(localTask.updatedAt || 0).getTime();
            if (remoteUpdated > localUpdated) {
                const changedBy = remoteChangedTask.assignee
                    ? (App.state.users.find(u => u.id === remoteChangedTask.assignee)?.name || 'коллегой')
                    : 'коллегой';
                App.showToast(
                    `⚠️ Задача "${localTask.title}" была изменена ${changedBy}. Данные обновлены.`,
                    'warning'
                );
                setTimeout(() => {
                    if (App.ui.currentTask === currentTaskId) {
                        App.openTaskDetail(currentTaskId);
                    }
                }, 500);
            }
        }
    }

    App.processSmartNotifications();
};

App.buildSyncPayload = function() {
    const payload = {};
    App.sync.sharedKeys.forEach(key => {
        payload[key] = App.state[key];
    });
    payload.tasks = payload.tasks.filter(t => t.visibility !== 'private');
    return payload;
};

App.syncAcquireLock = async function() {
    return true;
};

App.syncRemoveLock = function(data) {
    return data;
};

App.syncPush = async function() {
    if (!App.sync.handle) return;
    
    const run = async () => {
        const granted = await App.syncVerifyPermission(App.sync.handle, false);
        if (!granted) {
            App.syncSetStatus('needs-permission');
            return;
        }

        let remoteData = null;
        try {
            const file = await App.sync.dbFileHandle.getFile();
            const text = await file.text();
            if (text.trim()) {
                remoteData = JSON.parse(text);
            }
        } catch (e) {
            console.warn('syncPush: could not read remote data:', e);
        }

        if (remoteData && remoteData.tasks) {
            const conflicts = [];
            const payload = App.buildSyncPayload();
            if (!App.sync.baseVersions) App.sync.baseVersions = new Map();

            payload.tasks.forEach(localTask => {
                const remoteTask = remoteData.tasks.find(t => t.id === localTask.id);
                if (!remoteTask) return;

                const baseVersion = App.sync.baseVersions.get(localTask.id) || 1;
                const remoteVersion = remoteTask.version || 1;

                if (remoteVersion > baseVersion) {
                    conflicts.push({
                        taskId: localTask.id,
                        title: localTask.title,
                        baseVersion: baseVersion,
                        localVersion: localTask.version || 1,
                        remoteVersion: remoteVersion,
                        remoteTask: remoteTask,
                        localTask: localTask
                    });
                }
            });

            if (conflicts.length > 0) {
                const conflictList = conflicts.map(c => `• ${c.title}`).join('\n');
                App.showToast(
                    `Конфликт версий! ${conflicts.length} задач(и) были изменены другими пользователями:\n${conflictList}\nОбновите страницу, чтобы получить свежие данные.`,
                    'error'
                );

                conflicts.forEach(c => {
                    const idx = App.state.tasks.findIndex(t => t.id === c.taskId);
                    if (idx !== -1) {
                        App.state.tasks[idx] = JSON.parse(JSON.stringify(c.remoteTask));
                    }
                });

                try {
                    const file = await App.sync.dbFileHandle.getFile();
                    const text = await file.text();
                    if (text.trim()) await App.syncPullMerge(text);
                } catch (e) {
                    console.error('Auto-pull after conflict failed:', e);
                }

                App.syncSetStatus('error');
                return;
            }
        }

        let payload = App.buildSyncPayload();
        if (remoteData) {
            const merged = App.syncMergeTasks(
                payload.tasks, remoteData.tasks || [],
                App.state._tombstones || [], remoteData._tombstones || []
            );
            payload.tasks = merged.tasks;
            payload._tombstones = merged.tombstones;
            payload.changeLog = App.mergeChangeLog(payload.changeLog || [], remoteData.changeLog || []);

            const base = App.syncGetBase();
            ['statuses', 'users', 'columns', 'templates', 'relations', 'taskOrder'].forEach(key => {
                payload[key] = App.syncMergeConfigArray(key, payload[key], remoteData[key], base[key]);
            });
        }

        // 🔧 ИСПОЛЬЗУЕМ АТОМАРНУЮ ЗАПИСЬ ИЗ syncReliability.js
        if (typeof App.syncAtomicWrite === 'function') {
            await App.syncAtomicWrite(App.sync.handle, App.sync.dbFileHandle, payload);
        } else {
            // Fallback если syncReliability.js не загружен
            const writable = await App.sync.dbFileHandle.createWritable();
            await writable.write(JSON.stringify(payload, null, 2));
            await writable.close();
        }

        App.syncSetBase(payload);
        App.sync.lastSyncedAt = new Date().toISOString();
        App.syncSetStatus('connected');

        if (!App.sync.baseVersions) App.sync.baseVersions = new Map();
        payload.tasks.forEach(t => {
            if (t && t.id) {
                App.sync.baseVersions.set(t.id, t.version || 1);
            }
        });
        
        // 🔧 СОХРАНЯЕМ BASEVERSIONS В LOCALSTORAGE
        if (typeof App.syncSaveBaseVersions === 'function') {
            App.syncSaveBaseVersions();
        }
    }; // ← ВАЖНО: закрывающая скобка для run

    App._pushChain = (App._pushChain || Promise.resolve()).then(run, run);
    return App._pushChain;
}; // ← ВАЖНО: закрывающая скобка для syncPush

App.syncCycle = async function() {
    if (App.sync.syncing || !App.sync.handle) return;
    App.sync.syncing = true;
    App.syncSetStatus('syncing');

    try {
        const granted = await App.syncVerifyPermission(App.sync.handle, false);
        if (!granted) {
            App.syncSetStatus('needs-permission');
            return;
        }

        const locked = await App.syncAcquireLock();
        if (!locked) {
            console.log('Файл заблокирован, пропускаем цикл синхронизации');
            return;
        }

        let text;
        try {
            const file = await App.sync.dbFileHandle.getFile();
            text = await file.text();
        } catch (e) {
            // 🔧 RETRY ПРИ ОШИБКЕ ЧТЕНИЯ
            if (typeof App.syncWithRetry === 'function') {
                text = await App.syncWithRetry(async () => {
                    const file = await App.sync.dbFileHandle.getFile();
                    return await file.text();
                }, 'syncCycle.readFile');
            } else {
                throw e;
            }
        }

        if (text.trim()) {
            try {
                const data = JSON.parse(text);
                const dataWithoutLock = App.syncRemoveLock(data);
                await App.syncPullMerge(JSON.stringify(dataWithoutLock));
            } catch (e) {
                console.error('syncCycle: JSON parse error:', e);
                // 🔧 ВОССТАНОВЛЕНИЕ ИЗ BACKUP
                if (typeof App.syncRestoreFromBackup === 'function') {
                    const restored = await App.syncRestoreFromBackup(App.sync.handle, App.sync.dbFileHandle.name);
                    if (restored) {
                        if (typeof App.syncAtomicWrite === 'function') {
                            await App.syncAtomicWrite(App.sync.handle, App.sync.dbFileHandle, restored.data);
                        } else {
                            const writable = await App.sync.dbFileHandle.createWritable();
                            await writable.write(JSON.stringify(restored.data, null, 2));
                            await writable.close();
                        }
                        await App.syncPullMerge(JSON.stringify(restored.data));
                        App.showToast(
                            'Файл данных был повреждён и автоматически восстановлен из резервной копии (' + restored.source + ').',
                            'warning'
                        );
                    } else {
                        App.syncSetStatus('error');
                    }
                } else {
                    App.syncSetStatus('error');
                }
                return;
            }
        }

        await App.syncPush();
        App.syncSetStatus('connected');
        
        // 🔧 СКРЫВАЕМ БАННЕР ОШИБОК
        if (typeof App.syncShowStatusBanner === 'function') {
            App.syncShowStatusBanner('hide');
        }
    } catch (e) {
        console.error('syncCycle failed:', e);
        App.syncSetStatus('error');
        // 🔧 ПОКАЗЫВАЕМ БАННЕР ОШИБКИ
        if (typeof App.syncShowStatusBanner === 'function') {
            App.syncShowStatusBanner('error');
        }
    } finally {
        App.sync.syncing = false;
    }
};

App.syncStartPolling = function() {
    App.syncStopPolling();
    App.sync.polling = setInterval(() => App.syncCycle(), App.sync.intervalMs);
};

App.syncStopPolling = function() {
    if (App.sync.polling) clearInterval(App.sync.polling);
    App.sync.polling = null;
};