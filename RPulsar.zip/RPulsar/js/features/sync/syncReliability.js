// js/features/sync/syncReliability.js
// =====================================================================
// RPulsar Sync Reliability Layer
// Атомарная запись, ротация резервных копий, восстановление после
// повреждения, retry с экспоненциальной задержкой, персистентность
// базовых версий и статус-баннер для пользователя.
//
// Зачем: SMB-папка не гарантирует атомарность записи. Прерванная
// запись (сбой сети, питание, блокировка файла) раньше приводила к
// повреждению rtasks-database.json и потере данных для всей команды.
// =====================================================================
window.App = window.App || {};

App.syncReliability = {
    maxBackups: 5,   // сколько резервных копий хранить
    maxRetries: 3,   // попыток на операцию чтения/записи
    baseDelayMs: 500 // базовая задержка retry (500 → 1000 → 2000 мс)
};

// =====================================================================
// 1. АТОМАРНАЯ ЗАПИСЬ
// =====================================================================
// Стратегия "write-aside":
//   1) сохраняем резервную копию текущего файла;
//   2) пишем новые данные во временный файл (.tmp);
//   3) проверяем целостность .tmp (parse JSON);
//   4) переносим проверенное содержимое в основной файл;
//   5) удаляем .tmp.
//
// File System Access API не имеет rename(), поэтому шаг 4 — это
// чтение .tmp в память и запись в основной файл. Окно уязвимости
// сокращено с "всей записи" до миллисекунд, а backup гарантирует
// восстановление в любом случае.
// =====================================================================

/**
 * Атомарно записывает данные в файл с автоматическим backup.
 * @param {FileSystemDirectoryHandle} dirHandle - папка базы
 * @param {FileSystemFileHandle} fileHandle - целевой файл
 * @param {Object} data - данные для записи
 */
App.syncAtomicWrite = async function(dirHandle, fileHandle, data) {
    const fileName = fileHandle.name;
    const tmpName = fileName + '.tmp';
    const jsonString = JSON.stringify(data, null, 2);

    // 1. Backup текущего файла (если он существует и не пуст)
    try {
        const existing = await fileHandle.getFile();
        if (existing.size > 0) {
            const bakHandle = await dirHandle.getFileHandle(fileName + '.bak', { create: true });
            const bakWritable = await bakHandle.createWritable();
            await bakWritable.write(await existing.text());
            await bakWritable.close();
            await App.syncRotateBackups(dirHandle, fileName);
        }
    } catch (e) {
        // Файла ещё нет (первое создание базы) — backup не нужен
    }

    // 2. Запись во временный файл
    const tmpHandle = await dirHandle.getFileHandle(tmpName, { create: true });
    const tmpWritable = await tmpHandle.createWritable();
    await tmpWritable.write(jsonString);
    await tmpWritable.close();

    // 3. Верификация: читаем .tmp обратно и проверяем parse
    // Защита от частичной записи на уровне SMB
    const verifyHandle = await dirHandle.getFileHandle(tmpName);
    const verifyText = await (await verifyHandle.getFile()).text();
    JSON.parse(verifyText); // бросит исключение, если JSON битый

    // 4. Перенос в основной файл (критическая секция — миллисекунды)
    const mainWritable = await fileHandle.createWritable();
    await mainWritable.write(verifyText);
    await mainWritable.close();

    // 5. Удаление временного файла (некритично, если упадёт)
    try {
        await dirHandle.removeEntry(tmpName);
    } catch (e) {
        // .tmp останется — его подберёт cleanup при следующем старте
    }
};

// =====================================================================
// 2. РОТАЦИЯ BACKUP
// =====================================================================
// Храним maxBackups копий: file.bak.1 (самая свежая) … file.bak.N.
// Сдвигаем по одному, начиная со старшей, чтобы избежать гонки
// при параллельном доступе других клиентов.
// =====================================================================

/**
 * Ротация резервных копий: file.bak → file.bak.1 → … → file.bak.N
 * @param {FileSystemDirectoryHandle} dirHandle
 * @param {string} fileName - имя основного файла
 */
App.syncRotateBackups = async function(dirHandle, fileName) {
    const max = App.syncReliability.maxBackups;

    // Удаляем самую старую копию, если она есть
    try {
        await dirHandle.removeEntry(fileName + '.bak.' + max);
    } catch (e) { /* её нет — ок */ }

    // Сдвигаем копии от старшей к младшей (безопасный порядок)
    for (let i = max - 1; i >= 1; i--) {
        try {
            const src = await dirHandle.getFileHandle(fileName + '.bak.' + i);
            const content = await (await src.getFile()).text();
            const dst = await dirHandle.getFileHandle(fileName + '.bak.' + (i + 1), { create: true });
            const writable = await dst.createWritable();
            await writable.write(content);
            await writable.close();
            await dirHandle.removeEntry(fileName + '.bak.' + i);
        } catch (e) {
            // Копии .bak.i ещё нет — пропускаем
        }
    }

    // Свежий backup (.bak) становится .bak.1
    try {
        const src = await dirHandle.getFileHandle(fileName + '.bak');
        const content = await (await src.getFile()).text();
        const dst = await dirHandle.getFileHandle(fileName + '.bak.1', { create: true });
        const writable = await dst.createWritable();
        await writable.write(content);
        await writable.close();
        await dirHandle.removeEntry(fileName + '.bak');
    } catch (e) { /* .bak нет — ок */ }
};

// =====================================================================
// 3. ВОССТАНОВЛЕНИЕ ИЗ BACKUP
// =====================================================================
// Вызывается автоматически, когда основной файл повреждён
// (не парсится JSON или не проходит валидацию).
// Перебираем копии от самой свежей к самой старой.
// =====================================================================

/**
 * Пытается восстановить данные из резервных копий.
 * @param {FileSystemDirectoryHandle} dirHandle
 * @param {string} fileName - имя основного файла
 * @returns {Promise<{data: Object, source: string}|null>}
 */
App.syncRestoreFromBackup = async function(dirHandle, fileName) {
    const candidates = [];
    for (let i = 1; i <= App.syncReliability.maxBackups; i++) {
        candidates.push(fileName + '.bak.' + i);
    }

    for (const name of candidates) {
        try {
            const handle = await dirHandle.getFileHandle(name);
            const text = await (await handle.getFile()).text();
            if (!text.trim()) continue;

            const data = JSON.parse(text);
            if (App.isObjectSafe(data) && App.validateImportedData(data).valid) {
                console.log('[SyncReliability] Восстановление из ' + name);
                return { data: data, source: name };
            }
        } catch (e) {
            // Эта копия повреждена — пробуем следующую
        }
    }

    App.showToast('Резервные копии повреждены или отсутствуют. Обратитесь к администратору.', 'error');
    return null;
};

// =====================================================================
// 4. RETRY С ЭКСПОНЕНЦИАЛЬНОЙ ЗАДЕРЖКОЙ
// =====================================================================
// SMB может кратковременно блокировать файл или терять соединение.
// Вместо мгновенной ошибки повторяем операцию: 500 → 1000 → 2000 мс.
// =====================================================================

/**
 * Выполняет асинхронную операцию с retry.
 * @param {Function} operation - async-функция
 * @param {string} label - имя операции для логов
 * @returns {Promise<*>}
 */
App.syncWithRetry = async function(operation, label) {
    const maxRetries = App.syncReliability.maxRetries;
    const baseDelay = App.syncReliability.baseDelayMs;
    let lastError = null;

    for (let attempt = 1; attempt <= maxRetries; attempt++) {
        try {
            return await operation();
        } catch (e) {
            lastError = e;
            if (attempt < maxRetries) {
                const delay = baseDelay * Math.pow(2, attempt - 1);
                console.warn('[SyncReliability] ' + label + ': попытка ' + attempt +
                    ' не удалась, повтор через ' + delay + ' мс', e);
                await new Promise(function(resolve) { setTimeout(resolve, delay); });
            }
        }
    }
    throw lastError;
};

// =====================================================================
// 5. ПЕРСИСТЕНТНОСТЬ baseVersions
// =====================================================================
// Раньше baseVersions жили только в памяти (Map) и терялись при
// перезагрузке страницы — optimistic locking "слеп" до первого pull.
// Теперь база версий сохраняется в localStorage и восстанавливается
// при старте. Ключ привязан к имени файла базы.
// =====================================================================

/**
 * Сохраняет baseVersions в localStorage.
 */
App.syncSaveBaseVersions = function() {
    try {
        const fileName = App.sync.dbFileHandle ? App.sync.dbFileHandle.name : 'default';
        const entries = Array.from(App.sync.baseVersions.entries());
        localStorage.setItem('rtasks_base_versions_' + fileName, JSON.stringify(entries));
    } catch (e) {
        // localStorage переполнен или недоступен — некритично,
        // в худшем случае один цикл будет работать без базы версий
        console.warn('syncSaveBaseVersions failed:', e);
    }
};

/**
 * Загружает baseVersions из localStorage.
 * Вызывать после того, как App.sync.dbFileHandle установлен.
 */
App.syncLoadBaseVersions = function() {
    try {
        if (!App.sync.baseVersions) App.sync.baseVersions = new Map();
        const fileName = App.sync.dbFileHandle ? App.sync.dbFileHandle.name : 'default';
        const raw = localStorage.getItem('rtasks_base_versions_' + fileName);
        if (raw) {
            const entries = JSON.parse(raw);
            if (Array.isArray(entries)) {
                App.sync.baseVersions = new Map(entries);
                console.debug('[SyncReliability] Загружено baseVersions: ' + entries.length);
            }
        }
    } catch (e) {
        console.warn('syncLoadBaseVersions failed:', e);
        App.sync.baseVersions = new Map();
    }
};

// =====================================================================
// 6. САМООЧИСТКА ПОСЛЕ СБОЯ
// =====================================================================
// Если запись прервалась (питание/сеть), во временном файле может
// остаться полная свежая версия данных. Пытаемся спасти её,
// затем удаляем orphaned-файлы. Вызывать при подключении к базе.
// =====================================================================

/**
 * Удаляет orphaned .tmp и пытается спасти данные из него.
 */
App.syncCleanupOrphanedFiles = async function() {
    if (!App.sync.handle || !App.sync.dbFileHandle) return;
    const fileName = App.sync.dbFileHandle.name;
    const tmpName = fileName + '.tmp';

    try {
        const tmpHandle = await App.sync.handle.getFileHandle(tmpName);
        const tmpText = await (await tmpHandle.getFile()).text();

        // Пытаемся спасти данные из прерванной записи
        try {
            if (tmpText.trim()) {
                const tmpData = JSON.parse(tmpText);
                if (App.isObjectSafe(tmpData) && App.validateImportedData(tmpData).valid) {
                    const mainText = await (await App.sync.dbFileHandle.getFile()).text();
                    let mainOk = false;
                    try {
                        mainOk = !!mainText.trim() &&
                            App.validateImportedData(JSON.parse(mainText)).valid;
                    } catch (e) { /* основной файл битый */ }

                    if (!mainOk) {
                        // Основной файл повреждён, а .tmp цел — спасаем
                        const writable = await App.sync.dbFileHandle.createWritable();
                        await writable.write(tmpText);
                        await writable.close();
                        console.log('[SyncReliability] Данные спасены из прерванной записи (.tmp)');
                    }
                }
            }
        } catch (e) {
            // .tmp тоже битый — просто удаляем
        }

        await App.sync.handle.removeEntry(tmpName);
    } catch (e) {
        // .tmp отсутствует — всё чисто
    }
};

// =====================================================================
// 7. СТАТУС-БАННЕР ДЛЯ ПОЛЬЗОВАТЕЛЯ
// =====================================================================
// Интерфейс никогда не должен молчать (Правило обратной связи).
// При проблемах с синхронизацией показываем спокойный баннер,
// при восстановлении — убираем.
// =====================================================================

/**
 * Показывает/обновляет/скрывает баннер состояния синхронизации.
 * @param {'hide'|'error'|'reconnecting'|'restored'} type
 * @param {string} [message]
 */
App.syncShowStatusBanner = function(type, message) {
    let banner = document.getElementById('syncStatusBanner');

    if (type === 'hide') {
        if (banner) banner.classList.add('hidden');
        return;
    }

    if (!banner) {
        banner = document.createElement('div');
        banner.id = 'syncStatusBanner';
        banner.className = 'sync-status-banner hidden';
        banner.setAttribute('role', 'status');
        banner.setAttribute('aria-live', 'polite');
        const main = document.getElementById('main-content') || document.body;
        main.insertBefore(banner, main.firstChild);
    }

    const presets = {
        error: {
            cls: 'banner-error',
            icon: 'wifi-off',
            text: message || 'Нет связи с общей папкой. Изменения будут синхронизированы автоматически после восстановления соединения.'
        },
        reconnecting: {
            cls: 'banner-warning',
            icon: 'loader',
            text: message || 'Восстанавливаем соединение с общей папкой…'
        },
        restored: {
            cls: 'banner-success',
            icon: 'check',
            text: message || 'Соединение восстановлено, данные синхронизированы.'
        }
    };

    const preset = presets[type] || presets.error;
    banner.className = 'sync-status-banner ' + preset.cls;
    banner.innerHTML =
        '<span class="icon icon-sm" aria-hidden="true" data-icon="' + preset.icon + '"></span>' +
        '<span>' + App.escapeHtml(preset.text) + '</span>';
    if (App.renderAllIcons) App.renderAllIcons();

    if (type === 'restored') {
        setTimeout(function() {
            if (banner) banner.classList.add('hidden');
        }, 4000);
    }
};