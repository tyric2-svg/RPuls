// js/features/sync/syncLock.js
// =====================================================================
// File Locking для предотвращения гонки записи
// Использует .lock файл в общей папке как мьютекс
// =====================================================================
window.App = window.App || {};

App.syncLock = {
    lockFileName: '_sync.lock',
    lockTimeout: 10000, // 10 секунд максимум
    retryDelay: 500,    // 500мс между попытками
    maxRetries: 5       // максимум 5 попыток
};

/**
 * Пытается захватить lock на файл синхронизации.
 * Создаёт .lock файл с метаданными о владельце.
 * @returns {Promise<boolean>} true если lock получен
 */
App.syncLockAcquire = async function() {
    if (!App.sync.handle) return false;
    
    const lockData = {
        userId: App.state.currentUser,
        timestamp: Date.now(),
        hostname: location.hostname
    };
    
    // Проверяем, существует ли уже lock
    try {
        const existingLock = await App.sync.handle.getFileHandle(App.syncLock.lockFileName);
        const lockFile = await existingLock.getFile();
        const lockText = await lockFile.text();
        const existingLockData = JSON.parse(lockText);
        
        // Если lock старше timeout — считаем его abandoned
        if (Date.now() - existingLockData.timestamp > App.syncLock.lockTimeout) {
            console.log('[SyncLock] Found abandoned lock, removing');
            await App.sync.handle.removeEntry(App.syncLock.lockFileName);
        } else {
            // Lock активен — не можем захватить
            console.log('[SyncLock] Lock held by:', existingLockData.userId);
            return false;
        }
    } catch (e) {
        // Lock файл не существует — это нормально
    }
    
    // Создаём новый lock
    try {
        const lockHandle = await App.sync.handle.getFileHandle(App.syncLock.lockFileName, { create: true });
        const writable = await lockHandle.createWritable();
        await writable.write(JSON.stringify(lockData));
        await writable.close();
        console.log('[SyncLock] Acquired by:', App.state.currentUser);
        return true;
    } catch (e) {
        console.error('[SyncLock] Failed to acquire:', e);
        return false;
    }
};

/**
 * Освобождает lock.
 */
App.syncLockRelease = async function() {
    if (!App.sync.handle) return;
    
    try {
        await App.sync.handle.removeEntry(App.syncLock.lockFileName);
        console.log('[SyncLock] Released');
    } catch (e) {
        // Lock уже удалён — это нормально
    }
};

/**
 * Пытается захватить lock с retry.
 * @returns {Promise<boolean>}
 */
App.syncLockAcquireWithRetry = async function() {
    for (let attempt = 0; attempt < App.syncLock.maxRetries; attempt++) {
        const acquired = await App.syncLockAcquire();
        if (acquired) return true;
        
        console.log(`[SyncLock] Retry ${attempt + 1}/${App.syncLock.maxRetries}`);
        await new Promise(resolve => setTimeout(resolve, App.syncLock.retryDelay));
    }
    
    console.warn('[SyncLock] Failed to acquire after retries');
    return false;
};

/**
 * Выполняет операцию с автоматическим lock/unlock.
 * @param {Function} operation - async функция
 * @returns {Promise<*>} результат операции
 */
App.syncWithLock = async function(operation) {
    const acquired = await App.syncLockAcquireWithRetry();
    if (!acquired) {
        throw new Error('Failed to acquire sync lock');
    }
    
    try {
        return await operation();
    } finally {
        await App.syncLockRelease();
    }
};