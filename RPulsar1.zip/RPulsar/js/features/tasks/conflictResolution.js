// js/features/tasks/conflictResolution.js
window.App = window.App || {};

/**
 * Форматирует значение поля задачи для отображения в диалоге конфликта.
 * @param {string} field - имя поля
 * @param {*} value - значение
 * @returns {string} HTML-строка
 */
App._formatConflictField = function(field, value) {
    if (value === null || value === undefined || value === '') {
        return '<span style="color: var(--text-disabled); font-style: italic;">—</span>';
    }

    switch (field) {
        case 'status': {
            const status = App.state.statuses.find(s => s.id === value);
            if (!status) return App.escapeHtml(String(value));
            return `<span style="display: inline-flex; align-items: center; gap: 6px;">
                <span style="width: 8px; height: 8px; border-radius: 50%; background: ${App.safeColor(status.color)};"></span>
                ${App.escapeHtml(status.name)}
            </span>`;
        }

        case 'priority': {
            const labels = { high: 'Высокий', medium: 'Средний', low: 'Низкий' };
            const colors = { high: 'var(--danger)', medium: 'var(--warning)', low: 'var(--success)' };
            const label = labels[value] || value;
            return `<span style="display: inline-flex; align-items: center; gap: 6px;">
                <span style="width: 8px; height: 8px; border-radius: 50%; background: ${colors[value] || 'var(--text-secondary)'};"></span>
                ${App.escapeHtml(label)}
            </span>`;
        }

        case 'dueDate': {
            if (!value) return '<span style="color: var(--text-disabled); font-style: italic;">—</span>';
            const date = new Date(value);
            if (isNaN(date.getTime())) return App.escapeHtml(String(value));
            const isOverdue = date < new Date();
            const formatted = date.toLocaleDateString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' });
            return `<span style="${isOverdue ? 'color: var(--danger); font-weight: 500;' : ''}">${formatted}</span>`;
        }

        case 'assignee':
        case 'assignees': {
            const ids = Array.isArray(value) ? value : [value];
            if (ids.length === 0 || (ids.length === 1 && !ids[0])) {
                return '<span style="color: var(--text-disabled); font-style: italic;">Не назначен</span>';
            }
            const names = ids
                .filter(Boolean)
                .map(id => App.state.users.find(u => u.id === id)?.name || 'Неизвестный')
                .join(', ');
            return App.escapeHtml(names);
        }

        case 'visibility': {
            return value === 'private' ? '🔒 Приватная' : '🌐 Общая';
        }

        case 'description': {
            if (!value) return '<span style="color: var(--text-disabled); font-style: italic;">(без описания)</span>';
            const text = String(value);
            const truncated = text.length > 200 ? text.substring(0, 200) + '…' : text;
            return App.escapeHtml(truncated);
        }

        case 'title': {
            return `<strong>${App.escapeHtml(String(value))}</strong>`;
        }

        default:
            return App.escapeHtml(String(value));
    }
};

/**
 * Определяет, различаются ли два значения поля.
 */
App._isFieldDifferent = function(field, localValue, remoteValue) {
    // Нормализуем пустые значения
    const normalize = (v) => {
        if (v === null || v === undefined || v === '') return null;
        if (Array.isArray(v) && v.length === 0) return null;
        if (Array.isArray(v)) return JSON.stringify(v.sort());
        return String(v);
    };

    return normalize(localValue) !== normalize(remoteValue);
};

/**
 * Показывает диалог разрешения конфликта версий.
 * Сравнивает ВСЕ поля задачи и отображает различия.
 *
 * @param {string} taskId - ID задачи
 * @param {Object} remoteTask - версия задачи с сервера
 * @param {Object} localTask - локальная версия задачи (полный объект)
 */
App.showConflictDialog = function(taskId, remoteTask, localTask) {
    const remoteUser = remoteTask.assignee
        ? (App.state.users.find(u => u.id === remoteTask.assignee)?.name || 'коллегой')
        : 'коллегой';

    // Поля для сравнения в порядке важности
    const fieldsToCompare = [
        { key: 'title',       label: 'Название',    icon: 'file-text' },
        { key: 'description', label: 'Описание',    icon: 'align-left' },
        { key: 'status',      label: 'Статус',      icon: 'circle-dot' },
        { key: 'priority',    label: 'Приоритет',   icon: 'flag' },
        { key: 'dueDate',     label: 'Срок',        icon: 'calendar' },
        { key: 'assignee',    label: 'Исполнитель', icon: 'user' },
        { key: 'visibility',  label: 'Видимость',   icon: 'eye' },
    ];

    // Строим таблицу сравнения
    let rowsHtml = '';
    let diffCount = 0;

    fieldsToCompare.forEach(({ key, label, icon }) => {
        const localValue = localTask[key];
        const remoteValue = remoteTask[key];
        const isDifferent = App._isFieldDifferent(key, localValue, remoteValue);

        if (isDifferent) diffCount++;

        const rowClass = isDifferent
            ? 'conflict-row conflict-row--diff'
            : 'conflict-row conflict-row--same';

        const localFormatted = App._formatConflictField(key, localValue);
        const remoteFormatted = App._formatConflictField(key, remoteValue);

        rowsHtml += `
            <div class="${rowClass}" style="display: grid; grid-template-columns: 140px 1fr 1fr; gap: var(--space-3); padding: var(--space-3) var(--space-4); border-bottom: 1px solid var(--border-subtle); align-items: start; ${isDifferent ? 'background: var(--warning-bg);' : ''}">
                <div style="display: flex; align-items: center; gap: var(--space-2); font-size: var(--text-sm); color: var(--text-secondary); font-weight: 500;">
                    ${App.icon(icon, 'sm')}
                    ${label}
                    ${isDifferent ? '<span style="color: var(--warning); font-size: 10px;" title="Поля различаются">●</span>' : ''}
                </div>
                <div style="font-size: var(--text-sm); line-height: 1.5; word-break: break-word;">${localFormatted}</div>
                <div style="font-size: var(--text-sm); line-height: 1.5; word-break: break-word;">${remoteFormatted}</div>
            </div>
        `;
    });

    const html = `
        <div style="padding: var(--space-4); background: var(--warning-bg); border: 1px solid var(--warning); border-radius: var(--radius-md); margin-bottom: var(--space-4);">
            <div style="font-weight: 600; margin-bottom: var(--space-2); display: flex; align-items: center; gap: var(--space-2);">
                ${App.icon('alert-triangle', 'sm')} Конфликт версий
            </div>
            <div style="font-size: var(--text-sm); color: var(--text-secondary);">
                Задача была изменена пользователем
                <strong>${App.escapeHtml(remoteUser)}</strong>, пока вы её редактировали.
                Обнаружено <strong>${diffCount}</strong> различающихся полей.
            </div>
        </div>

        <!-- Заголовки колонок -->
        <div style="display: grid; grid-template-columns: 140px 1fr 1fr; gap: var(--space-3); padding: var(--space-2) var(--space-4); border-bottom: 2px solid var(--border-default); font-size: var(--text-xs); font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">
            <div style="color: var(--text-secondary);">Поле</div>
            <div style="color: var(--accent); display: flex; align-items: center; gap: var(--space-1);">
                ${App.icon('file-text', 'xs')} Ваша версия
            </div>
            <div style="color: var(--success); display: flex; align-items: center; gap: var(--space-1);">
                ${App.icon('refresh-cw', 'xs')} Версия коллеги
            </div>
        </div>

        <!-- Таблица сравнения -->
        <div style="border: 1px solid var(--border-subtle); border-radius: var(--radius-md); overflow: hidden; margin-bottom: var(--space-4); max-height: 400px; overflow-y: auto;">
            ${rowsHtml}
        </div>
    `;

    App.openDrawer('Разрешение конфликта', html, `
        <button class="btn btn-secondary" id="conflictAcceptRemote">
            ${App.icon('refresh-cw', 'sm')} Принять версию коллеги
        </button>
        <button class="btn btn-primary" id="conflictKeepLocal">
            ${App.icon('file-text', 'sm')} Перезаписать своей версией
        </button>
    `);

    // Принять чужую версию — переоткрыть Drawer с актуальными данными
    document.getElementById('conflictAcceptRemote')?.addEventListener('click', () => {
        App.closeTaskModal();
        App.openTaskDetail(taskId);
        App.ui.openedTaskVersion = App.state.tasks.find(t => t.id === taskId)?.version || 1;
        App.showToast('Принята версия коллеги', 'info');
    });

    // Перезаписать своей версией — сохранить ВСЕ поля локальной задачи
    document.getElementById('conflictKeepLocal')?.addEventListener('click', () => {
        const index = App.state.tasks.findIndex(t => t.id === taskId);
        if (index !== -1) {
            const currentVersion = App.state.tasks[index].version || 1;

            // Сохраняем ВСЕ поля из локальной задачи, а не только title и description
            const fieldsToRestore = ['title', 'description', 'status', 'priority', 'dueDate', 'assignee', 'assignees', 'visibility', 'tags', 'relations'];
            fieldsToRestore.forEach(field => {
                if (localTask[field] !== undefined) {
                    App.state.tasks[index][field] = JSON.parse(JSON.stringify(localTask[field]));
                }
            });

            App.state.tasks[index].version = currentVersion + 1;
            App.state.tasks[index].updatedAt = new Date().toISOString();
            App.saveState();
            App.render();
            App.ui.openedTaskVersion = App.state.tasks[index].version;
        }
        App.closeTaskModal();
        App.openTaskDetail(taskId);
        App.showToast('Ваши изменения сохранены (перезаписана версия коллеги)', 'warning');
    });
};