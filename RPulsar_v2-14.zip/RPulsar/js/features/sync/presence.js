// js/features/sync/presence.js
// =====================================================================
// RPulsar Presence System
// Показывает, кто онлайн и кто какую задачу редактирует.
// Работает через отдельные файлы _presence-{userId}.json в общей папке.
// =====================================================================
window.App = window.App || {};

App.presence = {
    heartbeatInterval: 10000, // 10 секунд
    offlineTimeout: 30000,    // 30 секунд — после этого пользователь считается офлайн
    polling: null,
    onlineUsers: new Map(),   // userId -> presence data
    maxVisibleAvatars: 5,     // максимум аватаров в header
};

// =====================================================================
// ЗАПИСЬ PRESENCE
// =====================================================================

/**
 * Записывает presence текущего пользователя в отдельный файл.
 * Вызывается каждые heartbeatInterval мс и при изменении editing.
 */
App.presenceWrite = async function() {
    if (!App.sync.handle || !App.state.currentUser) return;
    
    const userId = App.state.currentUser;
    const user = App.state.users.find(u => u.id === userId);
    if (!user) return;
    
    const fileName = `_presence-${userId}.json`;
    const data = {
        userId: userId,
        name: user.name,
        color: user.color || '#6B7280',
        lastSeen: new Date().toISOString(),
        editing: App.ui.currentTask || null,
        view: App.state.view || 'table',
        section: App.state.currentSection || 'tasks',
        appVersion: '4.72'
    };
    
    try {
        const fileHandle = await App.sync.handle.getFileHandle(fileName, { create: true });
        // Используем атомарную запись из syncReliability.js
        await App.syncAtomicWrite(App.sync.handle, fileHandle, data);
    } catch (e) {
        console.warn('[Presence] Ошибка записи:', e);
    }
};

// =====================================================================
// ЧТЕНИЕ PRESENCE
// =====================================================================

/**
 * Читает presence всех пользователей из файлов _presence-*.json.
 * Обновляет App.presence.onlineUsers и перерисовывает UI.
 */
App.presenceRead = async function() {
    if (!App.sync.handle) return;
    
    const onlineUsers = new Map();
    const now = Date.now();
    const offlineTimeout = App.presence.offlineTimeout;
    
    try {
        // Читаем все файлы _presence-*.json в папке
        for await (const entry of App.sync.handle.values()) {
            if (entry.kind === 'file' && 
                entry.name.startsWith('_presence-') && 
                entry.name.endsWith('.json')) {
                try {
                    const file = await entry.getFile();
                    const text = await file.text();
                    if (!text.trim()) continue;
                    
                    const data = JSON.parse(text);
                    const lastSeen = new Date(data.lastSeen).getTime();
                    
                    // Проверяем таймаут: если lastSeen старше 30 секунд — офлайн
                    if (now - lastSeen < offlineTimeout) {
                        onlineUsers.set(data.userId, data);
                    }
                    // Устаревшие файлы не удаляем — могут быть файлы других
                    // пользователей, и у нас может не быть прав на удаление.
                    // Они просто игнорируются при чтении.
                } catch (e) {
                    // Файл повреждён или не парсится — пропускаем
                    console.debug('[Presence] Пропускаем повреждённый файл:', entry.name);
                }
            }
        }
        
        App.presence.onlineUsers = onlineUsers;
        App.presenceRender();
    } catch (e) {
        console.warn('[Presence] Ошибка чтения:', e);
    }
};

// =====================================================================
// РЕНДЕРИНГ UI
// =====================================================================

/**
 * Главный рендер presence: обновляет все UI-элементы.
 */
App.presenceRender = function() {
    // Исключаем текущего пользователя из отображения
    const onlineUsers = Array.from(App.presence.onlineUsers.values())
        .filter(u => u.userId !== App.state.currentUser);
    
    // 1. Аватары онлайн в header
    App.presenceRenderHeaderAvatars(onlineUsers);
    
    // 2. Индикаторы редактирования на задачах (таблица + канбан)
    App.presenceRenderEditingIndicators();
    
    // 3. Предупреждение в drawer, если задачу редактирует кто-то другой
    App.presenceRenderDrawerWarning();
};

/**
 * Рендерит аватары онлайн-пользователей в header.
 */
App.presenceRenderHeaderAvatars = function(onlineUsers) {
    let container = document.getElementById('presenceAvatars');
    
    if (!container) {
        // Создаём контейнер в header-actions (перед кнопкой новой задачи)
        const headerActions = document.querySelector('.header-actions');
        if (!headerActions) return;
        
        container = document.createElement('div');
        container.id = 'presenceAvatars';
        container.className = 'presence-avatars';
        headerActions.insertBefore(container, headerActions.firstChild);
    }
    
    const maxVisible = App.presence.maxVisibleAvatars;
    const visible = onlineUsers.slice(0, maxVisible);
    const extra = onlineUsers.length - maxVisible;
    
    let html = '';
    visible.forEach(user => {
        const initials = user.name.split(' ')
            .map(n => n[0])
            .join('')
            .substring(0, 2)
            .toUpperCase();
        html += `
            <div class="presence-avatar" 
                 style="background: ${App.safeColor(user.color)}" 
                 title="${App.escapeHtml(user.name)} — онлайн"
                 data-user-id="${user.userId}">
                ${initials}
            </div>
        `;
    });
    
    if (extra > 0) {
        html += `
            <div class="presence-avatar presence-avatar-more" 
                 title="Ещё ${extra} онлайн">
                +${extra}
            </div>
        `;
    }
    
    container.innerHTML = html;
};

/**
 * Рендерит индикаторы редактирования на строках таблицы и карточках канбана.
 */
App.presenceRenderEditingIndicators = function() {
    // Собираем map: taskId -> user, который редактирует
    const editingMap = new Map();
    App.presence.onlineUsers.forEach(user => {
        if (user.editing && user.userId !== App.state.currentUser) {
            editingMap.set(user.editing, user);
        }
    });
    
    // === Таблица ===
    const rows = document.querySelectorAll('.task-row');
    rows.forEach(row => {
        const taskId = row.dataset.taskId;
        const editor = editingMap.get(taskId);
        
        let indicator = row.querySelector('.presence-editing-indicator');
        if (editor) {
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'presence-editing-indicator';
                // Вставляем в последнюю ячейку или в конец строки
                const lastCell = row.querySelector('td:last-child');
                if (lastCell) {
                    lastCell.appendChild(indicator);
                } else {
                    row.appendChild(indicator);
                }
            }
            indicator.innerHTML = `
                <span class="presence-editing-dot" 
                      style="background: ${App.safeColor(editor.color)}"></span>
                <span class="presence-editing-name">
                    ${App.escapeHtml(editor.name)} редактирует
                </span>
            `;
        } else if (indicator) {
            indicator.remove();
        }
    });
    
    // === Канбан ===
    const cards = document.querySelectorAll('.kanban-card');
    cards.forEach(card => {
        const taskId = card.dataset.taskId;
        const editor = editingMap.get(taskId);
        
        let indicator = card.querySelector('.presence-editing-indicator');
        if (editor) {
            if (!indicator) {
                indicator = document.createElement('div');
                indicator.className = 'presence-editing-indicator presence-editing-indicator-kanban';
                card.appendChild(indicator);
            }
            indicator.innerHTML = `
                <span class="presence-editing-dot" 
                      style="background: ${App.safeColor(editor.color)}"></span>
            `;
        } else if (indicator) {
            indicator.remove();
        }
    });
};

/**
 * Показывает предупреждение в drawer, если открытую задачу
 * редактирует другой пользователь.
 */
App.presenceRenderDrawerWarning = function() {
    if (!App.ui.currentTask || !App.ui.drawerOpen) return;
    
    const editor = Array.from(App.presence.onlineUsers.values())
        .find(u => u.editing === App.ui.currentTask && u.userId !== App.state.currentUser);
    
    let warning = document.getElementById('presenceDrawerWarning');
    
    if (editor) {
        if (!warning) {
            warning = document.createElement('div');
            warning.id = 'presenceDrawerWarning';
            warning.className = 'presence-drawer-warning';
            const drawerBody = document.getElementById('drawerBody');
            if (drawerBody) {
                drawerBody.insertBefore(warning, drawerBody.firstChild);
            }
        }
        warning.innerHTML = `
            <span class="icon icon-sm" data-icon="alert-circle"></span>
            <span>${App.escapeHtml(editor.name)} сейчас редактирует эту задачу. 
                  Ваши изменения могут конфликтовать.</span>
        `;
        if (App.renderAllIcons) App.renderAllIcons();
    } else if (warning) {
        warning.remove();
    }
};

// =====================================================================
// УПРАВЛЕНИЕ HEARTBEAT
// =====================================================================

/**
 * Запускает presence heartbeat: запись + чтение каждые 10 секунд.
 */
App.presenceStart = function() {
    App.presenceStop();
    
    // Сразу пишем и читаем при старте
    App.presenceWrite();
    App.presenceRead();
    
    // Запускаем периодический цикл
    App.presence.polling = setInterval(() => {
        App.presenceWrite();
        App.presenceRead();
    }, App.presence.heartbeatInterval);
    
    console.log('[Presence] Heartbeat запущен (интервал: ' + 
        App.presence.heartbeatInterval + 'мс)');
};

/**
 * Останавливает presence heartbeat.
 */
App.presenceStop = function() {
    if (App.presence.polling) {
        clearInterval(App.presence.polling);
        App.presence.polling = null;
        console.log('[Presence] Heartbeat остановлен');
    }
};

// =====================================================================
// УПРАВЛЕНИЕ РЕДАКТИРОВАНИЕМ
// =====================================================================

/**
 * Устанавливает задачу, которую редактирует текущий пользователь.
 * Вызывать при открытии модалки/drawer задачи.
 * @param {string} taskId - ID задачи
 */
App.presenceSetEditing = function(taskId) {
    App.ui.currentTask = taskId;
    // Сразу обновляем presence, чтобы коллеги увидели без задержки
    App.presenceWrite();
};

/**
 * Очищает задачу редактирования.
 * Вызывать при закрытии модалки/drawer.
 */
App.presenceClearEditing = function() {
    App.ui.currentTask = null;
    // Сразу обновляем presence
    App.presenceWrite();
};