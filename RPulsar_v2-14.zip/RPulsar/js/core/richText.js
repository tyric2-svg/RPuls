// js/core/richText.js
window.App = window.App || {};

/**
 * WYSIWYG-описание задачи хранится как HTML (из Quill) в общем JSON-файле,
 * который синхронизируется между браузерами всех сотрудников. Это значит,
 * что чужой (в том числе испорченный или недобросовестный) клиент теоретически
 * может записать в это поле произвольный HTML — при показе он попадёт на
 * экран остальных пользователей. Поэтому ЛЮБОЕ отображение описания задачи
 * идёт через App.sanitizeHtml(), а не напрямую через innerHTML.
 *
 * Разрешён только конкретный список тегов/атрибутов, которые реально
 * генерирует Quill (snow theme, базовые модули toolbar) — не общий
 * HTML-санитайзер на все случаи жизни.
 */

const RICH_TEXT_ALLOWED_TAGS = new Set([
    'P', 'BR', 'STRONG', 'B', 'EM', 'I', 'U', 'S', 'DEL',
    'BLOCKQUOTE', 'CODE', 'PRE', 'UL', 'OL', 'LI', 'A', 'SPAN'
]);

// Разрешённые атрибуты по тегам. '*' — общий для всех разрешённых тегов.
const RICH_TEXT_ALLOWED_ATTRS = {
    'A': ['href', 'target', 'rel'],
    'LI': ['data-list', 'class'],
    'UL': ['class'],
    'OL': ['class'],
    'SPAN': ['class']
};

// Quill использует эти классы для отступов списков и чек-листов —
// разрешаем только их по шаблону, а не произвольные имена классов.
const RICH_TEXT_ALLOWED_CLASS_PATTERN = /^ql-indent-[0-8]$/;
const RICH_TEXT_ALLOWED_DATA_LIST = new Set(['bullet', 'ordered', 'checked', 'unchecked']);

App.sanitizeHtml = function(html) {
    if (!html) return '';

    const template = document.createElement('template');
    template.innerHTML = html;

    const walk = (node) => {
        // Идём по копии списка детей — modifying live NodeList во время
        // обхода привело бы к пропуску узлов.
        Array.from(node.childNodes).forEach(child => {
            if (child.nodeType === Node.TEXT_NODE) {
                return; // текстовые узлы всегда безопасны
            }
            if (child.nodeType !== Node.ELEMENT_NODE) {
                child.remove(); // комментарии и прочее — удаляем
                return;
            }

            if (!RICH_TEXT_ALLOWED_TAGS.has(child.tagName)) {
                // Неизвестный/опасный тег (script, img, iframe, style и т.д.) —
                // не удаляем содержимое целиком, а разворачиваем: текст внутри
                // мог быть осмысленным содержимым описания. Сначала чистим
                // ЕГО СОБСТВЕННОЕ поддерево (рекурсия в свою же ветку, а не
                // повторный обход node — иначе ломается снэпшот childNodes,
                // по которому идёт внешний forEach).
                walk(child);
                while (child.firstChild) {
                    node.insertBefore(child.firstChild, child);
                }
                node.removeChild(child);
                return;
            }

            // Чистим атрибуты по белому списку для этого тега
            const allowedAttrs = RICH_TEXT_ALLOWED_ATTRS[child.tagName] || [];
            Array.from(child.attributes).forEach(attr => {
                if (!allowedAttrs.includes(attr.name)) {
                    child.removeAttribute(attr.name);
                }
            });

            if (child.tagName === 'A') {
                const href = child.getAttribute('href') || '';
                // Разрешаем только http(s)/mailto — блокируем javascript:, data: и т.д.
                if (!/^(https?:|mailto:)/i.test(href)) {
                    child.removeAttribute('href');
                } else {
                    child.setAttribute('target', '_blank');
                    child.setAttribute('rel', 'noopener noreferrer');
                }
            }

            if (child.hasAttribute('class')) {
                const classes = child.getAttribute('class').split(/\s+/)
                    .filter(c => RICH_TEXT_ALLOWED_CLASS_PATTERN.test(c));
                if (classes.length > 0) {
                    child.setAttribute('class', classes.join(' '));
                } else {
                    child.removeAttribute('class');
                }
            }

            if (child.hasAttribute('data-list')) {
                const value = child.getAttribute('data-list');
                if (!RICH_TEXT_ALLOWED_DATA_LIST.has(value)) {
                    child.removeAttribute('data-list');
                }
            }

            walk(child);
        });
    };

    walk(template.content);
    return template.innerHTML;
};

/**
 * Определяет, похож ли текст на уже сохранённый HTML (новый формат) —
 * в отличие от старого markdown-lite (**жирный**, *курсив*, `код`), который
 * хранился как обычный текст без тегов.
 */
App.looksLikeHtml = function(text) {
    return /<\/?[a-z][\s\S]*>/i.test(text || '');
};

/**
 * Разово конвертирует описание в старом markdown-lite формате (до перехода
 * на WYSIWYG-редактор) в эквивалентный HTML. Вызывается лениво — при первом
 * открытии задачи на редактирование/просмотр после обновления, а не разовым
 * проходом по всей базе. Если текст уже HTML — возвращает как есть.
 */
App.convertLegacyDescription = function(text) {
    if (!text) return '';
    if (App.looksLikeHtml(text)) return text;

    let safe = App.escapeHtml(text);
    safe = safe.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    safe = safe.replace(/(^|\s)\*([^*\n]+?)\*(\s|$|[.,!?])/g, '$1<em>$2</em>$3');
    safe = safe.replace(/~~(.+?)~~/g, '<s>$1</s>');
    safe = safe.replace(/`([^`\n]+?)`/g, '<code>$1</code>');
    safe = safe.replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2">$1</a>');
    safe = safe.replace(/\n/g, '<br>');
    return `<p>${safe}</p>`;
};

/**
 * Единая точка для отображения описания задачи в режиме "только чтение"
 * (превью в таблице/канбане) — конвертирует легаси-формат при необходимости
 * и всегда пропускает через sanitizeHtml перед вставкой в innerHTML.
 */
App.renderTaskDescriptionPreview = function(text) {
    if (!text) return '';
    const html = App.looksLikeHtml(text) ? text : App.convertLegacyDescription(text);
    return App.sanitizeHtml(html);
};

/**
 * Создаёт Quill-редактор в указанном контейнере. Тулбар намеренно ограничен
 * ровно тем набором форматирования, который умеет пропускать
 * App.sanitizeHtml — если добавить сюда кнопку (например, изображения или
 * произвольный цвет текста), санитайзер её результат тут же вырежет при
 * следующем показе, поэтому список должен обновляться синхронно с
 * RICH_TEXT_ALLOWED_TAGS/ATTRS выше.
 */
App.initRichTextEditor = function(containerId, initialHtml) {
    const quill = new Quill(`#${containerId}`, {
        theme: 'snow',
        placeholder: 'Добавьте описание...',
        modules: {
            toolbar: [
                ['bold', 'italic', 'underline', 'strike'],
                ['blockquote', 'code-block'],
                [{list: 'ordered'}, {list: 'bullet'}, {list: 'check'}],
                ['link'],
                ['clean']
            ]
        }
    });
    if (initialHtml) {
        // ВАЖНО: quill.root.innerHTML = ... меняет DOM, но не обновляет
        // внутреннюю модель Quill (Delta) — getText()/getContents() после
        // этого продолжат считать редактор пустым. dangerouslyPasteHTML
        // проводит HTML через тот же парсер, что обрабатывает вставку из
        // буфера обмена, и корректно синхронизирует и DOM, и модель.
        quill.clipboard.dangerouslyPasteHTML(App.sanitizeHtml(initialHtml));
    }
    return quill;
};
